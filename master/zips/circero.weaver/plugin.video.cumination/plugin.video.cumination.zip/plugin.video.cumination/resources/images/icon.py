# -*- coding: utf-8 -*-

import os
import bpy
import bpy.utils.previews
icons_dict = bpy.utils.previews.new()

# this will work for addons 
icons_dir = os.path.join(os.path.dirname(__file__), "images"))
